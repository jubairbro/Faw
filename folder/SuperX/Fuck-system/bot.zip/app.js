const sqlite3 = require('sqlite3').verbose();
const { Telegraf, Scenes, session } = require('telegraf');
const moment = require('moment');
const { createvmess } = require('./create/createvmess');
const { createvless } = require('./create/createvless');
const { createtrojan } = require('./create/createtrojan');
const { createshadowsocks } = require('./create/createshadowsocks');
// import create modules
const { createssh } = require('./create/createssh');
const { checkvmess } = require('./check/checkvmess');
const { checkvless } = require('./check/checkvless');
const { checktrojan } = require('./check/checktrojan');
const { checkshadowsocks } = require('./check/checkshadowsock');
const { checkssh } = require('./check/checkssh');
// import renew modules
const { renewvmess } = require('./renew/renewvmess');
const { renewvless } = require('./renew/renewvless');
const { renewtrojan } = require('./renew/renewtrojan');
const { renewshadowsocks } = require('./renew/renewshadowsocks');
const { renewssh } = require('./renew/renewssh');
// import delete modules
const { deletevmess } = require('./delete/deletevmess');
const { deletevless } = require('./delete/deletevless');
const { deletetrojan } = require('./delete/deletetrojan');
const { deleteshadowsocks } = require('./delete/deleteshadowsocks');
const { deletessh } = require('./delete/deletessh');

const { BOT_TOKEN, ADMIN } = require('/root/.bot/.vars.json');
const bot = new Telegraf(BOT_TOKEN);
// List of allowed admin IDs
const adminIds = ADMIN; // Replace with allowed admin IDs
console.log('Bot initialized');

// Connect to SQLite3
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('SQLite3 connection error:', err.message);
  } else {
    console.log('Connected to SQLite3');
  }
});

// Create Server table if it doesn't exist
db.run(`CREATE TABLE IF NOT EXISTS Server (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT,
  auth TEXT
)`, (err) => {
  if (err) {
    console.error('Error creating Server table:', err.message);
  } else {
    console.log('Server table created or already exists');
  }
});

// Store user state
const userState = {};
console.log('User state initialized');

// Add menu and start commands
bot.command('menu', async (ctx) => {
  console.log('Menu command received');
  if (!adminIds.includes(ctx.from.id)) {
    await ctx.reply('You do not have permission to access the bot.');
    return;
  }
  await sendMainMenu(ctx);
});

bot.command('start', async (ctx) => {
  console.log('Start command received');
  if (!adminIds.includes(ctx.from.id)) {
    await ctx.reply('You do not have permission to access the bot.');
    return;
  }
  await sendMainMenu(ctx);
});

bot.command('admin', async (ctx) => {
  console.log('Admin menu requested');
  
  if (!adminIds.includes(ctx.from.id)) {
    await ctx.reply('You do not have permission to access the admin menu.');
    return;
  }

  await sendAdminMenu(ctx);
});

async function sendMainMenu(ctx) {
  const keyboard = [
    [
      { text: '🍏 Service Create', callback_data: 'service_create' },
      { text: '🍎 Service Delete', callback_data: 'service_delete' },
    ],
    [
      { text: '🍊 Service Renew', callback_data: 'service_renew' },
      { text: '🍌 Service Check', callback_data: 'service_check' }
    ],
  ];

  const currentTime = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
  const messageText = `**Welcome to FTVPN VPN Bot!** 🚀
Automated VPN bot for managing 
VPN services easily and quickly.
**Current time:** ${currentTime}

Please select a service option:`;

  try {
    await ctx.editMessageText(messageText, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: keyboard
      }
    });
    console.log('Main menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // If the message cannot be edited, send a new message
      await ctx.reply(messageText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log('Main menu sent as new message');
    } else {
      console.error('Error sending main menu:', error);
    }
  }
}

// Function to handle all service types
async function handleServiceAction(ctx, action) {
  let keyboard;
  if (action === 'create') {
    keyboard = [
      [{ text: '🍏 Create SSH', callback_data: 'create_ssh' }],      
      [{ text: '🍏 Create Vmess', callback_data: 'create_vmess' }],
      [{ text: '🍏 Create Vless', callback_data: 'create_vless' }],
      [{ text: '🍏 Create Trojan', callback_data: 'create_trojan' }],
      [{ text: '🍏 Create Shadowsocks', callback_data: 'create_shadowsocks' }],
      [{ text: '🔙 Back', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'delete') {
    keyboard = [
      [{ text: '🍎 Delete SSH', callback_data: 'delete_ssh' }],      
      [{ text: '🍎 Delete Vmess', callback_data: 'delete_vmess' }],
      [{ text: '🍎 Delete Vless', callback_data: 'delete_vless' }],
      [{ text: '🍎 Delete Trojan', callback_data: 'delete_trojan' }],
      [{ text: '🍎 Delete Shadowsocks', callback_data: 'delete_shadowsocks' }],
      [{ text: '🔙 Back', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'renew') {
    keyboard = [
      [{ text: '🍊 Renew SSH', callback_data: 'renew_ssh' }],      
      [{ text: '🍊 Renew Vmess', callback_data: 'renew_vmess' }],
      [{ text: '🍊 Renew Vless', callback_data: 'renew_vless' }],
      [{ text: '🍊 Renew Trojan', callback_data: 'renew_trojan' }],
      [{ text: '🍊 Renew Shadowsocks', callback_data: 'renew_shadowsocks' }],
      [{ text: '🔙 Back', callback_data: 'send_main_menu' }]
    ];
  } else if (action === 'check') {
    keyboard = [
      [{ text: '🍌 Check SSH', callback_data: 'check_ssh' }],      
      [{ text: '🍌 Check Vmess', callback_data: 'check_vmess' }],
      [{ text: '🍌 Check Vless', callback_data: 'check_vless' }],
      [{ text: '🍌 Check Trojan', callback_data: 'check_trojan' }],
      [{ text: '🍌 Check Shadowsocks', callback_data: 'check_shadowsocks' }],
      [{ text: '🔙 Back', callback_data: 'send_main_menu' }]
    ];
  }

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: keyboard
    });
    console.log(`${action} service menu sent`);
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // If the message cannot be edited, send a new message
      await ctx.reply(`Select the service type you want to ${action}:`, {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
      console.log(`${action} service menu sent as new message`);
    } else {
      console.error(`Error sending ${action} menu:`, error);
    }
  }
}

async function sendAdminMenu(ctx) {
  const adminKeyboard = [
    [{ text: '➕ Add Server', callback_data: 'addserver' }],
    [{ text: '❌ Delete Server', callback_data: 'deleteserver' }],   
    [{ text: '📜 List Servers', callback_data: 'listserver' }],     
    [{ text: '🗑️ Reset Server', callback_data: 'resetdb' }],
    [{ text: '🔙 Back', callback_data: 'send_main_menu' }]
  ];

  try {
    await ctx.editMessageReplyMarkup({
      inline_keyboard: adminKeyboard
    });
    console.log('Admin menu sent');
  } catch (error) {
    if (error.response && error.response.error_code === 400) {
      // If the message cannot be edited, send a new message
      await ctx.reply('Admin Menu:', {
        reply_markup: {
          inline_keyboard: adminKeyboard
        }
      });
      console.log('Admin menu sent as new message');
    } else {
      console.error('Error sending admin menu:', error);
    }
  }
}

// Action handlers for all service types
bot.action('service_create', async (ctx) => {
  await handleServiceAction(ctx, 'create');
});

bot.action('service_delete', async (ctx) => {
  await handleServiceAction(ctx, 'delete');
});

bot.action('service_renew', async (ctx) => {
  await handleServiceAction(ctx, 'renew');
});

bot.action('service_check', async (ctx) => {
  await handleServiceAction(ctx, 'check');
});

// Action handler to return to main menu
bot.action('send_main_menu', async (ctx) => {
  await sendMainMenu(ctx);
});

// Action handlers for creating accounts
bot.action('create_vmess', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vmess');
});

bot.action('create_vless', async (ctx) => {
  await startSelectServer(ctx, 'create', 'vless');
});

bot.action('create_trojan', async (ctx) => {
  await startSelectServer(ctx, 'create', 'trojan');
});

bot.action('create_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'create', 'shadowsocks');
});

bot.action('create_ssh', async (ctx) => {
  await startSelectServer(ctx, 'create', 'ssh');
});

// Action handlers for deleting accounts
bot.action('delete_vmess', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vmess');
});

bot.action('delete_vless', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'vless');
});

bot.action('delete_trojan', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'trojan');
});

bot.action('delete_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'shadowsocks');
});

bot.action('delete_ssh', async (ctx) => {
  await startSelectServer(ctx, 'delete', 'ssh');
});

// Action handlers for renewing accounts
bot.action('renew_vmess', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vmess');
});

bot.action('renew_vless', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'vless');
});

bot.action('renew_trojan', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'trojan');
});

bot.action('renew_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'shadowsocks');
});

bot.action('renew_ssh', async (ctx) => {
  await startSelectServer(ctx, 'renew', 'ssh');
});

// Action handlers for checking accounts
bot.action('check_vmess', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vmess');
});

bot.action('check_vless', async (ctx) => {
  await startSelectServer(ctx, 'check', 'vless');
});

bot.action('check_trojan', async (ctx) => {
  await startSelectServer(ctx, 'check', 'trojan');
});

bot.action('check_shadowsocks', async (ctx) => {
  await startSelectServer(ctx, 'check', 'shadowsocks');
});

bot.action('check_ssh', async (ctx) => {
  await startSelectServer(ctx, 'check', 'ssh');
});

// Function to start selecting a server
async function startSelectServer(ctx, action, type) {
  try {
    console.log(`Starting ${action} process for ${type}`);
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ ATTENTION! No servers are available at the moment. Try again later!');
      }

      if (servers.length === 0) {
        console.log('No servers available');
        return ctx.reply('⚠️ ATTENTION! No servers are available at the moment. Try again later!');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `${action}_username_${type}_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Back to Main Menu', callback_data: 'send_main_menu' }]);

      ctx.answerCbQuery();
      ctx.deleteMessage();
      ctx.reply('Select a server:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });

      // Store user state
      userState[ctx.chat.id] = { step: `${action}_username_${type}` };
    });
  } catch (error) {
    console.error(`Error starting ${action} process for ${type}:`, error);
    await ctx.reply(`❌ FAILED! An error occurred while processing your request. Please try again later.`);
  }
}

// Handle server selection
bot.action(/(create|delete|renew|check)_username_(vmess|vless|trojan|shadowsocks|ssh)_(.+)/, async (ctx) => {
  const action = ctx.match[1];
  const type = ctx.match[2];
  const serverId = ctx.match[3];
  userState[ctx.chat.id] = { step: `username_${action}_${type}`, serverId, type, action };
  if (action === 'check') {
    let msg;
    if (type === 'vmess') {
      msg = await checkvmess(serverId);
    } else if (type === 'vless') {
      msg = await checkvless(serverId);
    } else if (type === 'trojan') {
      msg = await checktrojan(serverId);
    } else if (type === 'shadowsocks') {
      msg = await checkshadowsocks(serverId);
    } else if (type === 'ssh') {
      msg = await checkssh(serverId);
    }
    await ctx.reply(msg, { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  } else {
    await ctx.reply('👤 Enter username:');
  }
});

// Handle text input for various steps
bot.on('text', async (ctx) => {
  const state = userState[ctx.chat.id];

  if (!state) return; // If no state, ignore the message

  if (state.step.startsWith('username_')) {
    state.username = ctx.message.text;
    const { username, serverId, type, action } = state;
    let msg;
    if (action === 'create') {
      if (type === 'ssh') {
        state.step = `password_${state.action}_${state.type}`;
        await ctx.reply('🔑 Enter password:');
      } else {
        state.step = `exp_${state.action}_${state.type}`;
        await ctx.reply('⏳ Enter validity period (days):');
      }
    } else if (action === 'renew') {
      state.step = `exp_${state.action}_${state.type}`;
      await ctx.reply('⏳ Enter validity period (days):');
    } else if (action === 'delete') {
      if (type === 'vmess') {
        msg = await deletevmess(username, serverId);
      } else if (type === 'vless') {
        msg = await deletevless(username, serverId);
      } else if (type === 'trojan') {
        msg = await deletetrojan(username, serverId);
      } else if (type === 'shadowsocks') {
        msg = await deleteshadowsocks(username, serverId);
      } else if (type === 'ssh') {
        msg = await deletessh(username, serverId);
      }
      await ctx.reply(msg, { parse_mode: 'Markdown' });
      delete userState[ctx.chat.id];
    }
  } else if (state.step.startsWith('password_')) {
    state.password = ctx.message.text;
    state.step = `exp_${state.action}_${state.type}`;
    await ctx.reply('⏳ Enter validity period (days):');
  } else if (state.step.startsWith('exp_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ ATTENTION! Enter ONLY NUMBERS for the account validity period!');
      return;
    }
    state.exp = ctx.message.text;
    if (state.type === 'ssh') {
      state.step = `limitip_${state.action}_${state.type}`;
      await ctx.reply('🔢 Enter IP limit:');
    } else {
      state.step = `quota_${state.action}_${state.type}`;
      await ctx.reply('📊 Enter quota (GB):');
    }
  } else if (state.step.startsWith('quota_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ ATTENTION! Enter ONLY NUMBERS for the quota!');
      return;
    }
    state.quota = ctx.message.text;
    state.step = `limitip_${state.action}_${state.type}`;
    await ctx.reply('🔢 Enter IP limit:');
  } else if (state.step.startsWith('limitip_')) {
    if (!/^\d+$/.test(ctx.message.text)) {
      await ctx.reply('❌ ATTENTION! Enter ONLY NUMBERS for the IP limit!');
      return;
    }
    state.limitip = ctx.message.text;
    const { username, password, exp, quota, limitip, serverId, type, action } = state;
    let msg;
    if (action === 'create') {
      if (type === 'vmess') {
        msg = await createvmess(username, exp, quota, limitip, serverId);
      } else if (type === 'vless') {
        msg = await createvless(username, exp, quota, limitip, serverId);
      } else if (type === 'trojan') {
        msg = await createtrojan(username, exp, quota, limitip, serverId);
      } else if (type === 'shadowsocks') {
        msg = await createshadowsocks(username, exp, quota, limitip, serverId);
      } else if (type === 'ssh') {
        msg = await createssh(username, password, exp, limitip, serverId);
      }
    } else if (action === 'renew') {
      if (type === 'vmess') {
        msg = await renewvmess(username, exp, quota, limitip, serverId);
      } else if (type === 'vless') {
        msg = await renewvless(username, exp, quota, limitip, serverId);
      } else if (type === 'trojan') {
        msg = await renewtrojan(username, exp, quota, limitip, serverId);
      } else if (type === 'shadowsocks') {
        msg = await renewshadowsocks(username, exp, quota, limitip, serverId);
      } else if (type === 'ssh') {
        msg = await renewssh(username, exp, limitip, serverId);
      }
    }
    await ctx.reply(msg, { parse_mode: 'Markdown' });
    delete userState[ctx.chat.id];
  } else if (state.step === 'addserver') {
    const domain = ctx.message.text.trim();
    if (!domain) {
      await ctx.reply('⚠️ Domain cannot be empty. Please enter a valid server domain.');
      return;
    }

    state.step = 'addserver_auth';
    state.domain = domain;
    await ctx.reply('🔑 Please enter the server auth:');
  } else if (state.step === 'addserver_auth') {
    const auth = ctx.message.text.trim();
    if (!auth) {
      await ctx.reply('⚠️ Auth cannot be empty. Please enter a valid server auth.');
      return;
    }

    const { domain } = state;

    try {
      db.run('INSERT INTO Server (domain, auth) VALUES (?, ?)', [domain, auth], function(err) {
        if (err) {
          console.error('Error adding server:', err.message);
          ctx.reply('❌ An error occurred while adding the new server.');
        } else {
          ctx.reply(`✅ Server with domain ${domain} has been successfully added.`);
        }
      });
    } catch (error) {
      console.error('Error adding server:', error);
      await ctx.reply('❌ An error occurred while adding the new server.');
    }
    delete userState[ctx.chat.id];
  }
});

// ADMIN
bot.action('deleteserver', async (ctx) => {
  try {
    console.log('Delete server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ ATTENTION! An error occurred while retrieving the server list.');
      }

      if (servers.length === 0) {
        console.log('No servers available');
        return ctx.reply('⚠️ ATTENTION! No servers are available at the moment.');
      }

      const keyboard = servers.map(server => {
        return [{ text: server.domain, callback_data: `confirm_delete_server_${server.id}` }];
      });
      keyboard.push([{ text: '🔙 Back to Main Menu', callback_data: 'send_main_menu' }]);

      ctx.reply('Select the server to delete:', {
        reply_markup: {
          inline_keyboard: keyboard
        }
      });
    });
  } catch (error) {
    console.error('Error starting server deletion process:', error);
    await ctx.reply('❌ FAILED! An error occurred while processing your request. Please try again later.');
  }
});

bot.action(/confirm_delete_server_(\d+)/, async (ctx) => {
  try {
    db.run('DELETE FROM Server WHERE id = ?', [ctx.match[1]], function(err) {
      if (err) {
        console.error('Error deleting server:', err.message);
        return ctx.reply('⚠️ ATTENTION! An error occurred while deleting the server.');
      }

      if (this.changes === 0) {
        console.log('Server not found');
        return ctx.reply('⚠️ ATTENTION! Server not found.');
      }

      console.log(`Server with ID ${ctx.match[1]} successfully deleted`);
      ctx.reply('✅ Server successfully deleted.');
    });
  } catch (error) {
    console.error('Error deleting server:', error);
    await ctx.reply('❌ FAILED! An error occurred while processing your request. Please try again later.');
  }
});

bot.action('addserver', async (ctx) => {
  try {
    console.log('Add server process started');
    await ctx.answerCbQuery();
    await ctx.reply('🌐 Please enter the server domain/IP:');
    userState[ctx.chat.id] = { step: 'addserver' };
  } catch (error) {
    console.error('Error starting server addition process:', error);
    await ctx.reply('❌ FAILED! An error occurred while processing your request. Please try again later.');
  }
});

bot.action('listserver', async (ctx) => {
  try {
    console.log('List server process started');
    await ctx.answerCbQuery();
    
    db.all('SELECT * FROM Server', [], (err, servers) => {
      if (err) {
        console.error('Error fetching servers:', err.message);
        return ctx.reply('⚠️ ATTENTION! An error occurred while retrieving the server list.');
      }

      if (servers.length === 0) {
        console.log('No servers available');
        return ctx.reply('⚠️ ATTENTION! No servers are available at the moment.');
      }

      let serverList = '📜 *Server List* 📜\n\n';
      servers.forEach((server, index) => {
        serverList += `${index + 1}. ${server.domain}\n`;
      });

      ctx.reply(serverList, { parse_mode: 'Markdown' });
    });
  } catch (error) {
    console.error('Error retrieving server list:', error);
    await ctx.reply('❌ FAILED! An error occurred while processing your request. Please try again later.');
  }
});

bot.action('resetdb', async (ctx) => {
  try {
    await ctx.answerCbQuery();
    db.run('DELETE FROM Server', (err) => {
      if (err) {
        console.error('Error resetting Server table:', err.message);
        ctx.reply('❗️ ATTENTION! A SERIOUS ERROR occurred while resetting the database. Please contact the administrator immediately!');
      }
    });
    await ctx.reply('🚨 ATTENTION! The database has been FULLY RESET. All servers have been COMPLETELY DELETED.');
  } catch (error) {
    console.error('Error resetting database:', error);
    await ctx.reply('❗️ ATTENTION! A SERIOUS ERROR occurred while resetting the database. Please contact the administrator immediately!');
  }
});

// Start the bot
bot.launch().then(() => {
  console.log('Bot has started');
}).catch((error) => {
  console.error('Error starting bot:', error);
});