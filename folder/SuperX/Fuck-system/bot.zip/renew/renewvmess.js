const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function renewvmess(username, exp, quota, limitip, serverId) {
  console.log(`Renewing VMess account for ${username} with expiry ${exp} days, quota ${quota} GB, limit IP ${limitip} on server ${serverId}`);
  
  // Validate username
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) {
    return '❌ Invalid username. Please use only letters and numbers without spaces.';
  }

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/renewvmess?user=${username}&exp=${exp}"a=${quota}&iplimit=${limitip}&auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const vmessData = response.data.data;
            const msg = `
🌟 *RENEW VMESS PREMIUM* 🌟

🔹 *Account Information*
┌─────────────────────────────
│ Username: \`${username}\`
│ Expiry: \`${vmessData.exp}\`
│ Quota: \`${vmessData.quota}\`
│ IP Limit: \`${vmessData.limitip} IP\`
└─────────────────────────────
✅ Account ${username} successfully updated
✨ Thank you for using our services! ✨
`;
              console.log('VMess account renewed successfully');
              return resolve(msg);
            } else {
              console.log('Error renewing VMess account');
              return resolve(`❌ An error occurred: ${response.data.message}`);
            }
          })
        .catch(error => {
          console.error('Error while renewing VMess:', error);
          return resolve('❌ An error occurred while renewing VMess. Please try again later.');
        });
    });
  });
}

module.exports = { renewvmess };