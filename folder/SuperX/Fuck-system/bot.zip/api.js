const os = require('os');
const { exec, execSync, spawn } = require('child_process');
const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware to check password
const checkPassword = (req, res, next) => {
  const { auth } = req.query;
  const correctPassword = fs.readFileSync('/root/.key', 'utf8').trim(); // Read password from /root/.key
  
  if (auth !== correctPassword) {
    return res.status(401).send('<html><body><h1 style="text-align: center;">Access Denied</h1><p style="text-align: center;">You do not have permission to access this page.</p></body></html>');
  }
  
  next();
};

// Apply checkPassword middleware to all routes
app.use(checkPassword);

// Create SSH user
app.get("/createssh", (req, res) => {
  const { user, password, exp, iplimit } = req.query;
  if (!user || !password || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, iplimit, and password are required' });
  }
  
  console.log(`Received request to create SSH account with user: ${user}, exp: ${exp}, iplimit: ${iplimit}, password: ${password}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate ssh ${user} ${password} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`SSH account creation process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while creating the account', detail: output });
    }
    console.log(`SSH account successfully created for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "SSH account successfully created",
          data: {
            username: jsonResponse.data.username,
            password: jsonResponse.data.password,
            expired: jsonResponse.data.expired,            
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey
          }
        });
      } else {
        res.status(500).json({ error: "Failed to create SSH account", detail: jsonResponse.message });
      }
    } catch (err) {
      console.error(`JSON parsing error: ${err}`);
      res.status(500).json({ error: "An error occurred while processing the result", detail: err.message });
    }
  });
});

// Create VMess user
app.get("/createvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to create VMess account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VMess account creation process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while creating the account', detail: output });
    }
    console.log(`VMess account successfully created for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VMess account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vmess_tls_link: jsonResponse.data.vmess_tls_link,
            vmess_nontls_link: jsonResponse.data.vmess_nontls_link,
            vmess_grpc_link: jsonResponse.data.vmess_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while creating the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Create VLess user
app.get("/createvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to create VLess account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VLess account creation process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while creating the account', detail: output });
    }
    console.log(`VLess account successfully created for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VLess account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            vless_tls_link: jsonResponse.data.vless_tls_link,
            vless_nontls_link: jsonResponse.data.vless_nontls_link,
            vless_grpc_link: jsonResponse.data.vless_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while creating the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Create Trojan user
app.get("/createtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to create Trojan account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Trojan account creation process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while creating the account', detail: output });
    }
    console.log(`Trojan account successfully created for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Trojan account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            uuid: jsonResponse.data.uuid,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            trojan_tls_link: jsonResponse.data.trojan_tls_link,
            trojan_grpc_link: jsonResponse.data.trojan_grpc_link
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while creating the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Create Shadowsocks user
app.get("/createshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to create Shadowsocks account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apicreate shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Shadowsocks account creation process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while creating the account', detail: output });
    }
    console.log(`Shadowsocks account successfully created for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Shadowsocks account successfully created",
          data: {
            username: jsonResponse.data.username,
            expired: jsonResponse.data.expired,
            password: jsonResponse.data.password,
            method: jsonResponse.data.method,
            quota: jsonResponse.data.quota,
            ip_limit: jsonResponse.data.ip_limit,
            domain: jsonResponse.data.domain,
            ns_domain: jsonResponse.data.ns_domain,
            city: jsonResponse.data.city,
            pubkey: jsonResponse.data.pubkey,
            ss_link_ws: jsonResponse.data.ss_link_ws,
            ss_link_grpc: jsonResponse.data.ss_link_grpc
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while creating the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Check SSH user
app.get("/checkssh", (req, res) => { 
  
  const child = spawn("/bin/bash", ["-c", `apicheck ssh`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`SSH account check process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while checking the account', detail: output });
    }
    console.log(`SSH account successfully checked`);
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'SSH account not found' });
      }
    } catch (error) {
      console.error(`JSON parsing error: ${error}`);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

app.get("/checkvmess", (req, res) => { 

  console.log(`Received request to check VMess account with user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vmess`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VMess account check process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while checking the account', detail: output });
    }
    console.log(`VMess account successfully checked`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'VMess account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

app.get("/checkvless", (req, res) => { 

  console.log(`Received request to check VLess account with user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck vless`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VLess account check process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while checking the account', detail: output });
    }
    console.log(`VLess account successfully checked`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'VLess account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

app.get("/checktrojan", (req, res) => { 

  console.log(`Received request to check Trojan account with user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck trojan`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Trojan account check process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while checking the account', detail: output });
    }
    console.log(`Trojan account successfully checked`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Trojan account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

app.get("/checkshadowsocks", (req, res) => { 

  console.log(`Received request to check Shadowsocks account with user: `);
  
  const child = spawn("/bin/bash", ["-c", `apicheck shadowsocks`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Shadowsocks account check process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while checking the account', detail: output });
    }
    console.log(`Shadowsocks account successfully checked`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Shadowsocks account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Delete SSH user
app.get("/deletessh", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  console.log(`Received request to delete SSH account with user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete ssh ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`SSH account deletion process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while deleting the account', detail: output });
    }
    console.log(`SSH account successfully deleted for user: ${user}`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'SSH account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Delete VMess user
app.get("/deletevmess", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  console.log(`Received request to delete VMess account with user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vmess ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VMess account deletion process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while deleting the account', detail: output });
    }
    console.log(`VMess account successfully deleted for user: ${user}`);
    
    try {
      // Remove extra commas before parsing JSON
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'VMess account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Delete VLess user
app.get("/deletevless", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  console.log(`Received request to delete VLess account with user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete vless ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VLess account deletion process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while deleting the account', detail: output });
    }
    console.log(`VLess account successfully deleted for user: ${user}`);
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'VLess account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Delete Trojan user
app.get("/deletetrojan", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  console.log(`Received request to delete Trojan account with user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete trojan ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Trojan account deletion process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while deleting the account', detail: output });
    }
    console.log(`Trojan account successfully deleted for user: ${user}`);
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Trojan account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Delete Shadowsocks user
app.get("/deleteshadowsocks", (req, res) => {
  const { user } = req.query;
  if (!user) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  console.log(`Received request to delete Shadowsocks account with user: ${user}`);
  
  const child = spawn("/bin/bash", ["-c", `apidelete shadowsocks ${user}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Shadowsocks account deletion process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while deleting the account', detail: output });
    }
    console.log(`Shadowsocks account successfully deleted for user: ${user}`);
    
    try {
      const cleanedOutput = output.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
      const jsonResponse = JSON.parse(cleanedOutput);
      if (jsonResponse.status === "success" && jsonResponse.data) {
        res.json({
          status: "success",
          message: jsonResponse.data.message,
          data: jsonResponse.data
        });
      } else {
        res.status(404).json({ error: 'Shadowsocks account not found' });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Renew SSH user
app.get("/renewssh", (req, res) => {
  const { user, exp, iplimit } = req.query;
  if (!user || !exp || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, and iplimit are required' });
  }
  
  console.log(`Received request to renew SSH account with user: ${user}, exp: ${exp}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew ssh ${user} ${exp} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`SSH account renewal process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while renewing the account', detail: output });
    }
    console.log(`SSH account successfully renewed for user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "SSH account successfully renewed",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while renewing the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Renew VMess user
app.get("/renewvmess", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to renew VMess account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vmess ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VMess account renewal process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while renewing the account', detail: output });
    }
    console.log(`VMess account successfully renewed for user: ${user}`);
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VMess account successfully renewed",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while renewing the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Renew VLess user
app.get("/renewvless", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to renew VLess account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew vless ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`VLess account renewal process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while renewing the account', detail: output });
    }
    console.log(`VLess account successfully renewed for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "VLess account successfully renewed",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while renewing the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Renew Trojan user
app.get("/renewtrojan", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to renew Trojan account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew trojan ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Trojan account renewal process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while renewing the account', detail: output });
    }
    console.log(`Trojan account successfully renewed for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Trojan account successfully renewed",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while renewing the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

// Renew Shadowsocks user
app.get("/renewshadowsocks", (req, res) => {
  const { user, exp, quota, iplimit } = req.query;
  if (!user || !exp || !quota || !iplimit) {
    return res.status(400).json({ error: 'Username, expiry, quota, and iplimit are required' });
  }
  
  console.log(`Received request to renew Shadowsocks account with user: ${user}, exp: ${exp}, quota: ${quota}, iplimit: ${iplimit}`);
  
  const child = spawn("/bin/bash", ["-c", `apirenew shadowsocks ${user} ${exp} ${quota} ${iplimit}`], {
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  child.stdin.end();
  let output = '';
  child.stdout.on('data', (data) => {
    output += data.toString();
  });
  
  child.stderr.on('data', (data) => {
    console.error(`Error: ${data}`);
    output += data.toString();
  });
  
  child.on('close', (code) => {
    if (code !== 0) {
      console.log(`Shadowsocks account renewal process failed with code: ${code}`);
      return res.status(500).json({ error: 'An error occurred while renewing the account', detail: output });
    }
    console.log(`Shadowsocks account successfully renewed for user: ${user}`);
    
    try {
      const jsonResponse = JSON.parse(output);
      if (jsonResponse.status === "success") {
        res.json({
          status: "success",
          message: "Shadowsocks account successfully renewed",
          data: {
            username: jsonResponse.data.username,
            exp: jsonResponse.data.exp,
            quota: jsonResponse.data.quota,
            limitip: jsonResponse.data.limitip
          }
        });
      } else {
        res.status(500).json({ error: 'An error occurred while renewing the account', detail: jsonResponse.message });
      }
    } catch (error) {
      console.error('JSON parsing error:', error);
      res.status(500).json({ error: 'An error occurred while processing JSON output' });
    }
  });
});

const PORT = process.env.PORT || 5888;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});