const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function checkshadowsocks(serverId) {
  console.log(`Checking Shadowsocks account on server ${serverId}`);

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/checkshadowsocks?auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const shadowsocksData = response.data.data;
            let msg = `
🌟 *CHECK SHADOWSOCKS ACCOUNT* 🌟
`;
            shadowsocksData.forEach(user => {
              msg += `
┌─────────────────────────────
│ Username: \`${user.user}\`
│ Usage: \`${user.usage}\`
│ Quota: \`${user.quota}\`
│ IP Limit: \`${user.ip_limit}\`
│ IP Count: \`${user.ip_count}\`
│ Log Count: \`${user.log_count}\`
└─────────────────────────────
`;
            });
            msg += `✨ Thank you for using our service! ✨`;
            console.log('Shadowsocks account checked successfully');
            return resolve(msg);
          } else {
            console.log('Error checking Shadowsocks account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while checking Shadowsocks:', error);
          return resolve('❌ An error occurred while checking Shadowsocks. Please try again later.');
        });
    });
  });
}

module.exports = { checkshadowsocks };