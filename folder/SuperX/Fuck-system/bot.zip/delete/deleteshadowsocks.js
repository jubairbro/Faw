const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function deleteshadowsocks(username, serverId) {
  console.log(`Deleting Shadowsocks account for ${username} on server ${serverId}`);
  
  // Validate username
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) {
    return '❌ Invalid username. Please use only letters and numbers without spaces.';
  }

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/deleteshadowsocks?user=${username}&auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const msg = `✅ Shadowsocks account for ${username} successfully deleted.`;
            console.log('Shadowsocks account deleted successfully');
            return resolve(msg);
          } else {
            console.log('Error deleting Shadowsocks account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while deleting Shadowsocks:', error);
          return resolve('❌ An error occurred while deleting Shadowsocks. Please try again later.');
        });
    });
  });
}

module.exports = { deleteshadowsocks };