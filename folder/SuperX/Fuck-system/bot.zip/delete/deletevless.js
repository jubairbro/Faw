const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function deletevless(username, serverId) {
  console.log(`Deleting VLESS account for ${username} on server ${serverId}`);
  
  // Validate username
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) {
    return '❌ Invalid username. Please use only letters and numbers without spaces.';
  }

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/deletevless?user=${username}&auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const msg = `✅ VLESS account for ${username} successfully deleted.`;
            console.log('VLESS account deleted successfully');
            return resolve(msg);
          } else {
            console.log('Error deleting VLESS account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while deleting VLESS:', error);
          return resolve('❌ An error occurred while deleting VLESS. Please try again later.');
        });
    });
  });
}

module.exports = { deletevless };