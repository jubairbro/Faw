const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

async function deletessh(username, serverId) {
  console.log(`Deleting SSH account for ${username} on server ${serverId}`);
  
  // Validate username
  if (/\s/.test(username) || /[^a-zA-Z0-9]/.test(username)) {
    return '❌ Invalid username. Please use only letters and numbers without spaces.';
  }

  // Fetch domain from database
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Server WHERE id = ?', [serverId], (err, server) => {
      if (err) {
        console.error('Error fetching server:', err.message);
        return resolve('❌ Server not found. Please try again.');
      }

      if (!server) return resolve('❌ Server not found. Please try again.');

      const domain = server.domain;
      const auth = server.auth;
      const param = `:5888/deletessh?user=${username}&auth=${auth}`;
      const url = `http://${domain}${param}`;
      axios.get(url)
        .then(response => {
          if (response.data.status === "success") {
            const msg = `✅ SSH account for ${username} successfully deleted.`;
            console.log('SSH account deleted successfully');
            return resolve(msg);
          } else {
            console.log('Error deleting SSH account');
            return resolve(`❌ An error occurred: ${response.data.message}`);
          }
        })
        .catch(error => {
          console.error('Error while deleting SSH:', error);
          return resolve('❌ An error occurred while deleting SSH. Please try again later.');
        });
    });
  });
}

module.exports = { deletessh };